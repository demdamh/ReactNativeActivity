import React, { useState } from 'react';
import { View, Text, TextInput, TouchableOpacity, ImageBackground, ScrollView, StyleSheet } from 'react-native';

const bgimage = require('./assets/R.png');

const App = () => {
  const [studentName, setStudentName] = useState('');
  const [studentAge, setStudentAge] = useState('');
  const [studentBday, setStudentBday] = useState('');
  const [studentAdd, setStudentAdd] = useState('');
  const [studentCourse, setStudentCourse] = useState('');
  const [studentsInfo, setStudentsInfo] = useState([]);
  const [isFormSubmitted, setIsFormSubmitted] = useState(false);

  const SubmitInformation = () => {
    const newStudent = {
      key: Math.random().toString(),
      name: studentName,
      age: studentAge,
      birthday: studentBday,
      address: studentAdd,
      course: studentCourse,
    };

    setStudentsInfo(prevInfo => [...prevInfo, newStudent]);
    setIsFormSubmitted(true);

    setStudentName('');
    setStudentAge('');
    setStudentBday('');
    setStudentAdd('');
    setStudentCourse('');
  };

  return (
    <ImageBackground source={bgimage} style={styles.backgroundImage}>
      <ScrollView contentContainerStyle={styles.scrollViewContainer}>
        <View style={styles.formContainer}>
          <Text style={styles.formTitle}>Student Information</Text>

          {!isFormSubmitted ? (
            <>
              <TextInput
                style={styles.inputField}
                placeholder="Enter Name"
                value={studentName}
                onChangeText={setStudentName}
              />
              <TextInput
                style={styles.inputField}
                placeholder="Enter Age"
                keyboardType="numeric"
                value={studentAge}
                onChangeText={setStudentAge}
              />
              <TextInput
                style={styles.inputField}
                placeholder="Enter Birthday"
                value={studentBday}
                onChangeText={setStudentBday}
              />
              <TextInput
                style={styles.inputField}
                placeholder="Enter Address"
                value={studentAdd}
                onChangeText={setStudentAdd}
              />
              <TextInput
                style={styles.inputField}
                placeholder="Enter Course"
                value={studentCourse}
                onChangeText={setStudentCourse}
              />

              <TouchableOpacity style={styles.submitButton} onPress={SubmitInformation}>
                <Text style={styles.submitButtonText}>Submit</Text>
              </TouchableOpacity>
            </>
          ) : (
            <View style={styles.userInfoContainer}>
              <Text style={[styles.userInfoText, styles.italicBoldText]}>Name: {studentsInfo[0].name}</Text>
              <Text style={[styles.userInfoText, styles.italicBoldText]}>Age: {studentsInfo[0].age}</Text>
              <Text style={[styles.userInfoText, styles.italicBoldText]}>Birthday: {studentsInfo[0].birthday}</Text>
              <Text style={[styles.userInfoText, styles.italicBoldText]}>Address: {studentsInfo[0].address}</Text>
              <Text style={[styles.userInfoText, styles.italicBoldText]}>Course: {studentsInfo[0].course}</Text>
            </View>
          )}
        </View>
      </ScrollView>
    </ImageBackground>
  );
};

export default App;

const styles = StyleSheet.create({
  backgroundImage: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    width: '100%',
    height: '100%',
    resizeMode: 'cover',
  },
  scrollViewContainer: {
    padding: 15,
    alignItems: 'center',
    flexGrow: 1,
  },
  formContainer: {
    backgroundColor: 'white',
    padding: 20,
    borderWidth: 1,
    borderColor: '#ccc',
    borderRadius: 8,
    width: '80%',
    maxWidth: 350,
    alignItems: 'center',
    marginTop: 30,
    opacity: 1.0,
  },
  formTitle: {
    fontSize: 32,
    color: 'blue',
    fontWeight: 'bold',
    marginBottom: 20,
    textAlign: 'center',
  },
  inputField: {
    width: '100%',
    height: 55,
    paddingLeft: 15,
    marginBottom: 15,
    borderColor: 'blue',
    borderWidth: 1,
    fontSize: 22,
    borderRadius: 5,
  },
  submitButton: {
    backgroundColor: 'yellow',
    padding: 12,
    marginBottom: 20,
    borderRadius: 5,
    width: '60%',
    alignItems: 'center',
  },
  submitButtonText: {
    fontSize: 24,
    color: 'blue',
    fontWeight: 'bold',
  },
  userInfoContainer: {
    backgroundColor: 'white',
    padding: 30,
    marginTop: 20,
    borderWidth: 1,
    borderColor: 'blue',
    borderRadius: 8,
    width: '80%',
    maxWidth: 350,
  },
  userInfoText: {
    fontSize: 28,
    color: 'blue',
    marginBottom: 15,
  },
  italicBoldText: {
    fontStyle: 'italic',
    fontWeight: 'bold',
  },
});